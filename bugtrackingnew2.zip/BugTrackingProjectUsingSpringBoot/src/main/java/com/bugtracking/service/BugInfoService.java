package com.bugtracking.service;

import java.util.*;

import org.springframework.data.domain.Sort;

import com.bugtracking.entity.BugInfoEntity;



public interface BugInfoService {
	public String createBug(BugInfoEntity bug);
	public String updateBug(BugInfoEntity bug);
	public Optional<BugInfoEntity> getBug(int bug_id);
	public List<BugInfoEntity> getAllBugs();
//	public List<BugInfoEntity> getAllBugsByStatus(String bug_status);
	public String deleteBug(int bug_id);
	public List<BugInfoEntity> getAllBugsByStatus(Sort bug_status);
	
	
}
