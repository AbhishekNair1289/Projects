package com.bugtracking.service;

import java.util.List;

import com.bugtracking.entity.ProjectEntity;

public interface ProjectService {

	public String addProject(ProjectEntity projectEntity);
	
	public String deleteProject(long projId);
	
	public String updateProject(ProjectEntity projectEntity);
	
	public ProjectEntity getProject(long projId);
	
	public List<ProjectEntity> getAllProjects();
}
