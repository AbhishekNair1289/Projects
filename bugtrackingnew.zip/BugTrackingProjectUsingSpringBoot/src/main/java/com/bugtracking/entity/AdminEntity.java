package com.bugtracking.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "admininfo")
public class AdminEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "admin_id", length=10)
	private long id;
	
	@Column(name = "admin_name", length=20)
	@NotEmpty(message = "The Admin Name cannot be empty")
	private String name;
	
	@Column(name = "admin_email", length=20)
	@Email
	@NotEmpty(message = "The Email id cannot be empty")
	private String mail;
	
	@Column(name = "admin_password", length=20)
	@NotEmpty(message = "The password cannot be empty")
	private String password;
	
	@Column(name = "admin_contact", length=10)
	@NotEmpty(message = "The Contact cannot be empty")
	private long contact;

	
	public AdminEntity(long id, @NotEmpty(message = "The Admin Name cannot be empty") String name,
			@Email @NotEmpty(message = "The Email id cannot be empty") String mail,
			@NotEmpty(message = "The password cannot be empty") String password,
			@NotEmpty(message = "The Contact cannot be empty") long contact) {
		super();
		this.id = id;
		this.name = name;
		this.mail = mail;
		this.password = password;
		this.contact = contact;
	}


	@Override
	public String toString() {
		return "AdminEntity [id=" + id + ", name=" + name + ", mail=" + mail + ", password=" + password + ", contact="
				+ contact + "]";
	}


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getMail() {
		return mail;
	}


	public void setMail(String mail) {
		this.mail = mail;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public long getContact() {
		return contact;
	}


	public void setContact(long contact) {
		this.contact = contact;
	}


	public AdminEntity() {
		super();

	}

}
