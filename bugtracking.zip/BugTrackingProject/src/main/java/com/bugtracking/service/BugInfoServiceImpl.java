package com.bugtracking.service;

import java.util.*;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bugtracking.dao.BugInfoDao;
import com.bugtracking.entity.BugInfoEntity;



@Service
@Transactional
public class BugInfoServiceImpl implements BugInfoService {
	@Autowired
	BugInfoDao dao;
	@Override
	public String createBug(BugInfoEntity bug) {
		dao.save(bug);
		return "Bug Created Successfully!";
	}

	@Override
	public String updateBug(BugInfoEntity bug) {
		dao.update(bug);
		return "Bug updated Successfully!";
	}

	@Override
	public String deleteBug(long bug_id) {
		dao.deleteById(bug_id);
		return "Bug Deleted Successfully!";
	}

	@Override
	public BugInfoEntity getBug(long bug_id) {
		return dao.findById(bug_id);
	}

	@Override
	public List<BugInfoEntity> getAllBugs() {
		return dao.findAll();
	}

	@Override
	public List<BugInfoEntity> getAllBugsByStatus(String bug_status) {
		return dao.findByStatus(bug_status);
	}
}
