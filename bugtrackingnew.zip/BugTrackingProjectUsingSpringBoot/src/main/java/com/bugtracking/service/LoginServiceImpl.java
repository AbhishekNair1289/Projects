package com.bugtracking.service;

public class LoginServiceImpl {

}
