package com.bugtracking.controller;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bugtracking.entity.BugInfoEntity;
import com.bugtracking.service.BugInfoService;


@RestController
@RequestMapping("/bug-info")
public class BugInfoController {
	@Autowired
	private BugInfoService bugService;
	@PostMapping
	public String createBug(@RequestBody BugInfoEntity bug) {
		return bugService.createBug(bug);
	}
	@PutMapping
	public String updateBug(@RequestBody BugInfoEntity bug) {
        return bugService.updateBug(bug);
    }
	@DeleteMapping("/{bug_id}")
	public void deleteBug(@PathVariable Long bug_id) {
        bugService.deleteBug(bug_id);
    }
	@GetMapping("/{bug_id}")
	public BugInfoEntity getBug(@PathVariable Long bug_id) {
	return bugService.getBug(bug_id);
	}
    @GetMapping
    public List<BugInfoEntity> getAllBugs() {
        return bugService.getAllBugs();
    }
    @GetMapping("/{bug_id}")
    public List<BugInfoEntity> getAllBugsByStatus(@PathVariable String bug_status) {
        return bugService.getAllBugs();
    }
}
