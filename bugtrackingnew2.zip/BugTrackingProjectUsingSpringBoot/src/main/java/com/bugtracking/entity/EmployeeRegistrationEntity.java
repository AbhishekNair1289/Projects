package com.bugtracking.entity;

public class EmployeeRegistrationEntity {

}
