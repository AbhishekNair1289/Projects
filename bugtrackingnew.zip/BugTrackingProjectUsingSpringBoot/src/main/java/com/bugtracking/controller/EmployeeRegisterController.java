package com.bugtracking.controller;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bugtracking.entity.EmployeeEntity;
import com.bugtracking.exception.DuplicateRecordException;
import com.bugtracking.exception.RecordNotFoundException;
import com.bugtracking.service.EmployeeRegisterServiceImpl;




@RestController
@RequestMapping("/bugtracker")
public class EmployeeRegisterController {

	
    @Autowired
    private EmployeeRegisterServiceImpl empRegis;
 
    // Log
    public static Logger log = Logger.getLogger(EmployeeEntity.class.getName());
 
 // ADDING THE USER DETAILS
    @PostMapping("/employeeregister")
    public ResponseEntity<EmployeeEntity> EmployeeRegister(@Valid @RequestBody EmployeeEntity userbasic) throws DuplicateRecordException 
    {
        EmployeeEntity empRegister = empRegis.empRegister(userbasic);
        return new ResponseEntity<EmployeeEntity>(empRegister, HttpStatus.OK);
    }
    
 // GET USER DETAILS BY EMAIL
    @GetMapping("/userregister/{email}")
    public ResponseEntity<EmployeeEntity> showEmployeeRegistrationInformation(@PathVariable("email") String email)
            throws RecordNotFoundException 
            {
        EmployeeEntity empRegister = empRegis.showempRegistrationInformationByEmail(email);
        return new ResponseEntity<EmployeeEntity>(empRegister, HttpStatus.OK);
            }
}
