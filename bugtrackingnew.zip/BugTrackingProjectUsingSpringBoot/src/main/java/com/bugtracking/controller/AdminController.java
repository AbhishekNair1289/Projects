package com.bugtracking.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bugtracking.entity.AdminEntity;
import com.bugtracking.entity.EmployeeEntity;
import com.bugtracking.entity.ProjectEntity;
import com.bugtracking.service.AdminService;
import com.bugtracking.service.EmployeeServices;
import com.bugtracking.service.ProjectService;


@RestController
@RequestMapping("/bugtracker")
public class AdminController {

	@Autowired
	private AdminService adminService;
	@Autowired
	private ProjectService service;
	@Autowired
	private EmployeeServices employeeService;

	
    
	@PostMapping("/admin/registration")   
	//localhost:8080/bugtracker/admin/registration
	public String createAdmin(@RequestBody AdminEntity admin) {
		return adminService.createAdmin(admin);
	}

	@GetMapping("/admin/{adminId}")
	public AdminEntity getadminById(@PathVariable Long adminId) {
		return adminService.getByAdminId(adminId);
	}

	@GetMapping("/project/getallProjects")
	public List<ProjectEntity> getAllProjects() {
		return service.getAllProjects();
	}

	@GetMapping("/employee/getallemployee")
	public List<EmployeeEntity> getAllEmployees() {
		return employeeService.getAllEmployees();
	}

	@GetMapping("/project/getProject/{pid}")
	public ProjectEntity getProject(@PathVariable("pid") long projId) {
		return service.getProject(projId);
	}

	@PostMapping("/project/addProject")
	public String addProject(@RequestBody @Valid ProjectEntity projectEntity) {
		return service.addProject(projectEntity);
	}

	@DeleteMapping("/project/deleteProject/{pid}")
	public String deleteProject(@PathVariable("pid") long projId) {
		return service.deleteProject(projId);
	}

}
