package com.bugtracking.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bugtracking.dao.ProjectDao;
import com.bugtracking.entity.ProjectEntity;

@Service
@Transactional
public class ProjectServiceImpl implements ProjectService{

	@Autowired
	ProjectDao dao;


	@Override
	public String addProject(ProjectEntity projectEntity) {
		dao.save(projectEntity);
		return "Project Inserted Successfully";
	}

	@Override
	public String deleteProject(long projId) {
		dao.deleteById(projId);
		return "Project Deleted Successfully";
		
	}

	@Override
	public String updateProject(ProjectEntity projectEntity) {
		dao.save(projectEntity);
		return "Project Updated Successfully";
	}

	@Override
	public ProjectEntity getProject(long projId) {
		Optional<ProjectEntity>projectEntity=dao.findById(projId);
		return projectEntity.get();
	}

	@Override
	public List<ProjectEntity> getAllProjects() {
		return dao.findAll();
	}
	
	
	
	
}
