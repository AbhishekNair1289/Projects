package com.bugtracking.service;

import java.util.*;

import com.bugtracking.entity.BugInfoEntity;



public interface BugInfoService {
	public String createBug(BugInfoEntity bug);
	public String updateBug(BugInfoEntity bug);
	public String deleteBug(long bug_id);
	public BugInfoEntity getBug(long bug_id);
	public List<BugInfoEntity> getAllBugs();
	public List<BugInfoEntity> getAllBugsByStatus(String bug_status);
	
	
}
