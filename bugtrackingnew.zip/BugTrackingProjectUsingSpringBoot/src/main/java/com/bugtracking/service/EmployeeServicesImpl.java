package com.bugtracking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bugtracking.dao.Employeedao;
import com.bugtracking.entity.EmployeeEntity;

@Service
@Transactional
public class EmployeeServicesImpl implements EmployeeServices {

	@Autowired
	Employeedao employeeDao;

	@Override
	public String createEmployee(EmployeeEntity employeeEntity) {
		employeeDao.save(employeeEntity);
		return "Employee Created Successfully";
	}

	@Override
	public String updateEmployee(EmployeeEntity employeeEntity) {
		employeeDao.update(employeeEntity);
		return "Employee Updated Successfully";
	}

	@Override
	public String deleteEmployee(Long employeeId) {
		employeeDao.delete(employeeId);
		return "Employee Deleted Successfully";
	}

	@Override
	public Optional<EmployeeEntity> getEmployeeById(Long employeeId) {
		return employeeDao.findById(employeeId);
	}

	@Override
	public List<EmployeeEntity> getAllEmployees() {
		return employeeDao.findAll();
	}
}
