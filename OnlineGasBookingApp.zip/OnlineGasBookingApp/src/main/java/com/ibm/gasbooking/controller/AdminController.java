package com.ibm.gasbooking.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.gasbooking.entity.Admin;
import com.ibm.gasbooking.service.AdminService;
import com.ibm.gasbooking.service.AdminServiceImpl;

@RestController
@RequestMapping("/admin")
public class AdminController {
	@Autowired
	AdminServiceImpl service;
	
	// http://localhost:5050/admin/addAdmin

	
	@PostMapping("/addAdmin")
	public String addAdmin(@RequestBody Admin admin) {
		return service.addAdmin(admin);
	}

	// http://localhost:5050/admin/updateAdmin

	
	@PutMapping("/updateAdmin")
	public String updateAdmin(@RequestBody  Admin admin) {
		return service.updateAdmin(admin);
	}

	// http://localhost:5050/admin/deleteAdmin

	
	@DeleteMapping("/deleteAdmin")
	public String deleteAdmin(@PathVariable("aid")int adminId) {
		return service.deleteAdmin(adminId);
	}

	@GetMapping("/getAdmin/{aid}")
	public Admin getAdmin(@PathVariable("aid")int adminId) {
		return service.getAdmin(adminId);
	}
	
	@GetMapping("/getBookings")
	public List<Admin>getAllBooking(){
		return service.getAllBookings();
	}

	@GetMapping("/getBookingsForDay")
	public List<Admin>getAllBookingForDay(){
		return service.getAllBookingsForDays();
	}
}

