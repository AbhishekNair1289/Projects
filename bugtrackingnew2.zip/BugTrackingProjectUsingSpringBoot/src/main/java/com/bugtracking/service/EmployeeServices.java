package com.bugtracking.service;

import java.util.List;
import java.util.Optional;

import com.bugtracking.entity.EmployeeEntity;

public interface EmployeeServices {
	    
	    public String createEmployee(EmployeeEntity employeeEntity);
	    
	    public String updateEmployee(EmployeeEntity employeeEntity);
	    
	    public String deleteEmployee(String emailid);
	    
	    public Optional<EmployeeEntity> getEmployeeById(String emailid);
	    
	    public List<EmployeeEntity> getAllEmployees();
	}

