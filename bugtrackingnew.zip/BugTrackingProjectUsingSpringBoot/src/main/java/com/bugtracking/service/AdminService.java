package com.bugtracking.service;


import com.bugtracking.entity.AdminEntity;


public interface AdminService {

	public String createAdmin(AdminEntity admin);
    
    public AdminEntity getByAdminId(Long adminId);
    
}
