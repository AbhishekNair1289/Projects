package com.bugtracking.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bugtracking.entity.AdminEntity;
import com.bugtracking.service.AdminServiceImpl;


@RestController
@RequestMapping("/bugtracker")
public class AdminController {

	@Autowired
	private AdminServiceImpl adminService;
	
	
    
	@PostMapping("/admin/registration")   //http://localhost:4321/bugtracker/admin/registration
	public String createAdmin(@RequestBody AdminEntity admin) {
		return adminService.createAdmin(admin);
	}

	@GetMapping("/admin/{email}") //http://localhost:4321/bugtracker/admin/{email}
	public AdminEntity getadminById(@PathVariable String emailid) {
		return adminService.getByAdminId(emailid);
	}



}
