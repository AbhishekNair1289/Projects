package com.ibm.gasbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineGasBookingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
