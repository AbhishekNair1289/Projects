package com.bugtracking.service;

import java.util.Optional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.bugtracking.dao.EmployeeRegisterDao;
import com.bugtracking.entity.EmployeeEntity;

import com.bugtracking.exception.RecordNotFoundException;

import com.bugtracking.exception.DuplicateRecordException;






public class EmployeeRegisterServiceImpl implements EmployeeRegisterService{

	static Logger log = Logger.getLogger(EmployeeRegisterServiceImpl.class.getClass());
	
	@Autowired
    private EmployeeRegisterDao empRegisterDao;
	
	@Override
    public EmployeeEntity empRegister(EmployeeEntity empbasic) throws DuplicateRecordException 
    {
        log.info("Service Layer-Entry-userRegister");
        EmployeeEntity user = new EmployeeEntity();
        if (empbasic.getEmail().isEmpty()) 
        {
            log.warn("WARN:Email should not be Empty");
            throw new DuplicateRecordException("User details should not be null");
        }
        log.info("Service Layer-Exit-userRegister");
        user = empRegisterDao.saveAndFlush(empbasic);
        return user;
    }

	@Override
	public EmployeeEntity showempRegistrationInformationByEmail(String email)
			throws RecordNotFoundException {
		if (email == null) {
			throw new RecordNotFoundException("Null email entered");
		}
		log.info("Service Layer-Entry-showUserRegistrationInformation");
		Optional<EmployeeEntity> userbasic = empRegisterDao.findById(email);
		if (userbasic == null) {
			log.warn("WARN:Details should not be null");
			throw new RecordNotFoundException("User details not found");
		}
		log.info("Service Layer-Exit-showUserRegistrationInformation");
		return userbasic.get();
	}
 
	 
}
