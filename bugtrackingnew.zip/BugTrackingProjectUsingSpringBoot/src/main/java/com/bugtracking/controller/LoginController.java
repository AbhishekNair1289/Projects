package com.bugtracking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bugtracking.entity.AdminEntity;
import com.bugtracking.entity.EmployeeEntity;
import com.bugtracking.service.LoginServiceImpl;

@RestController
@RequestMapping("/login")
public class LoginController {
	@Autowired
	LoginServiceImpl loginService;

//	@GetMapping("/employeelogin/{userEmail}/{password}")
//	public ResponseEntity<Object> verifyUser(@PathVariable("userEmail") String userEmail,
//			@PathVariable("password") String password)
//			throws RegistrationException, RecordNotFoundException, DuplicateRecordException {
//		EmployeeEntity empUser = loginService.authenticateUser(userEmail, password);
//		// Log.info(" user signin");
//		EntityModel<EmployeeEntity> resource = EntityModel.of(empUser);
//
//		return new ResponseEntity<Object>(resource, HttpStatus.OK);
//	}
//
//	@GetMapping("/adminlogin/{adminEmail}/{password}")
//	public ResponseEntity<Object> adminVerfication(@PathVariable("adminEmail") String adminEmail,
//			@PathVariable("password") String password) 
//					throws RegistrationException, RecordNotFoundException,
//			DuplicateRecordException, InvalidDetailsException, LoanApplicationException {
//		AdminEntity admin = loginService.authenticateAdmin(adminEmail, password);// Log.info("admin sign in");
//		EntityModel<AdminEntity> resource = EntityModel.of(admin);
//
//		return new ResponseEntity<Object>(resource, HttpStatus.OK);
//	}

}
