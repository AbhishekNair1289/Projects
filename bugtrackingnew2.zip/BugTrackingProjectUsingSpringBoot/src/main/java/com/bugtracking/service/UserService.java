package com.bugtracking.service;

public interface UserService {

	public String showmenu();

}
