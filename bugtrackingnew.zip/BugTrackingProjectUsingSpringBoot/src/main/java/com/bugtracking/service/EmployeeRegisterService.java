package com.bugtracking.service;

import java.util.List;

import com.bugtracking.entity.EmployeeEntity;
//import com.bugtracking.entity.EmployeeRegistrationEntity;
import com.bugtracking.exception.DuplicateRecordException;
import com.bugtracking.exception.RecordNotFoundException;



public interface EmployeeRegisterService {
	 // ADDING AN USER
    public EmployeeEntity empRegister(EmployeeEntity userbasic) throws DuplicateRecordException;
 
    //GET USER BY EMAIL
    public EmployeeEntity showempRegistrationInformationByEmail(String email)throws RecordNotFoundException;
 

}
