package com.bugtracking.service;

import java.util.List;

import com.bugtracking.entity.AdminEntity;
import com.bugtracking.entity.EmployeeEntity;
import com.bugtracking.exception.RecordNotFoundException;
import com.bugtracking.exception.RegistrationException;



public interface LoginService {
	public EmployeeEntity authenticateEmployee(String userEmail,String password) throws RegistrationException, RecordNotFoundException ;
	   public List<EmployeeEntity> getAllEmployeeDetails();
	   public AdminEntity authenticateAdmin(String adminEmail,String password) throws RegistrationException, RecordNotFoundException;
	   public List<AdminEntity> getAllAdminDetails();

}
