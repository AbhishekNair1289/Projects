package com.bugtracking.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bugtracking.entity.AdminEntity;
import com.bugtracking.entity.EmployeeEntity;
import com.bugtracking.entity.ProjectEntity;
import com.bugtracking.service.AdminService;
import com.bugtracking.service.EmployeeServices;
import com.bugtracking.service.ProjectService;

@RestController
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private AdminService adminService;
	@Autowired
	private ProjectService service;
	@Autowired
	private EmployeeServices employeeService;

	@PostMapping
	public String createAdmin(@RequestBody AdminEntity admin) {
		return adminService.createAdmin(admin);
	}

	@GetMapping("/{adminId}")
	public AdminEntity getadminById(@PathVariable Long adminId) {
		return adminService.getAdminById(adminId);
	}

	@GetMapping("/getProjects")
	public List<ProjectEntity> getAllProjects() {
		return service.getAllProjects();
	}

	@GetMapping
	public List<EmployeeEntity> getAllEmployees() {
		return employeeService.getAllEmployees();
	}

	@GetMapping("/getProject/{pid}")
	public ProjectEntity getProject(@PathVariable("pid") long projId) {
		return service.getProject(projId);
	}

	@PostMapping("/addProject")
	public String addProject(@RequestBody @Valid ProjectEntity projectEntity) {
		return service.addProject(projectEntity);
	}

	@DeleteMapping("/deleteProject/{pid}")
	public String deleteProject(@PathVariable("pid") long projId) {
		return service.deleteProject(projId);
	}

}
