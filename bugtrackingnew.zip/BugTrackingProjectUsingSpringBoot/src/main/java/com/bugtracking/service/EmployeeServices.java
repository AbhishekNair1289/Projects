package com.bugtracking.service;

import java.util.List;
import java.util.Optional;

import com.bugtracking.entity.EmployeeEntity;

public interface EmployeeServices {
	    
	    public String createEmployee(EmployeeEntity employeeEntity);
	    
	    public String updateEmployee(EmployeeEntity employeeEntity);
	    
	    public String deleteEmployee(Long employeeId);
	    
	    public Optional<EmployeeEntity> getEmployeeById(Long employeeId);
	    
	    public List<EmployeeEntity> getAllEmployees();
	}

