package com.bugtracking.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "admininfo")
public class AdminEntity {

	@Id
	@Column(name = "aid")
	private long admin_id;
	@Column(name = "aname")
	@NotEmpty(message = "The Admin Name cannot be empty")
	private String admin_name;
	@Column(name = "amail")
	@NotEmpty(message = "The Email id cannot be empty")
	private String admin_mail;
	@Column(name = "apass")
	@NotEmpty(message = "The password cannot be empty")
	private String admin_password;
	@Column(name = "acon")
	@NotEmpty(message = "The Contact cannot be empty")
	private String admin_contact;

	public long getAdmin_id() {
		return admin_id;
	}

	public void setAdmin_id(long admin_id) {
		this.admin_id = admin_id;
	}

	public String getAdmin_name() {
		return admin_name;
	}

	public void setAdmin_name(String admin_name) {
		this.admin_name = admin_name;
	}

	public String getAdmin_mail() {
		return admin_mail;
	}

	public void setAdmin_mail(String admin_mail) {
		this.admin_mail = admin_mail;
	}

	public String getAdmin_password() {
		return admin_password;
	}

	public void setAdmin_password(String admin_password) {
		this.admin_password = admin_password;
	}

	public String getAdmin_contact() {
		return admin_contact;
	}

	public void setAdmin_contact(String admin_contact) {
		this.admin_contact = admin_contact;
	}

	@Override
	public String toString() {
		return "AdminEntity [admin_id=" + admin_id + ", admin_name=" + admin_name + ", admin_mail=" + admin_mail
				+ ", admin_password=" + admin_password + ", admin_contact=" + admin_contact + "]";
	}

	public AdminEntity(long admin_id, @NotEmpty(message = "The Admin Name cannot be empty") String admin_name,
			@NotEmpty(message = "The Email id cannot be empty") String admin_mail,
			@NotEmpty(message = "The password cannot be empty") String admin_password,
			@NotEmpty(message = "The Contact cannot be empty") String admin_contact) {
		super();
		this.admin_id = admin_id;
		this.admin_name = admin_name;
		this.admin_mail = admin_mail;
		this.admin_password = admin_password;
		this.admin_contact = admin_contact;
	}

	public AdminEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

}
