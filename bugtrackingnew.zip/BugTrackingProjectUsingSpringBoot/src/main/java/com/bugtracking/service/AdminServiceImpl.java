package com.bugtracking.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bugtracking.dao.AdminDao;
import com.bugtracking.entity.AdminEntity;

@Service
@Transactional
public class AdminServiceImpl implements AdminService{
	
	@Autowired
    AdminDao adminDao;

    @Override
    public String createAdmin(AdminEntity admin) {
        adminDao.save(admin);
        return "Employee Created Successfully";
    }

    @Override
    public AdminEntity getByAdminId(Long adminId) {
        return adminDao.findByadminid(adminId);
    }

    

}
