package com.bugtracking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BugTrackingProjectUsingSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(BugTrackingProjectUsingSpringBootApplication.class, args);
	}

}
