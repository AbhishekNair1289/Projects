package com.bugtracking.service;


import java.util.Optional;

import com.bugtracking.entity.AdminEntity;


public interface AdminService {

	public String createAdmin(AdminEntity admin);
    
    public AdminEntity getByAdminId(String emailid);
    
}
