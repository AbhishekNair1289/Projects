package com.bugtracking.exception;

public class BugNotFoundException {

	
		
		private static final long serialVersionUID = 1L;
		public BugNotFoundException(String msg) {
			super();
		}

	

}
