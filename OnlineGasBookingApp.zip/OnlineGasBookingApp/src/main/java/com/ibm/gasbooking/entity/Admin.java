package com.ibm.gasbooking.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name="admin_data")
public class Admin {

	@Id
	@Column(name="aid")
	@Min(value=100,message="can't be less than 100")
	private int adminId;
	@NotEmpty
	private String username;
	@NotBlank
	private String password;
	@NotEmpty
	private String address;
	@NotEmpty
	private String mobileno;
	@NotEmpty
	private String email;

	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Admin(int adminId, String username, String password, String address, String mobileno, String email) {
		super();
		this.adminId = adminId;
		this.username = username;
		this.password = password;
		this.address = address;
		this.mobileno = mobileno;
		this.email = email;
	}

	public Admin() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", username=" + username + ", password=" + password + ", address="
				+ address + ", mobileno=" + mobileno + ", email=" + email + "]";
	}

}
