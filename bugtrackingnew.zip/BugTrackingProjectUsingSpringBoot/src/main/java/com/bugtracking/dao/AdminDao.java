package com.bugtracking.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.bugtracking.entity.AdminEntity;

//@Repository
public interface AdminDao extends JpaRepository<AdminEntity, Long> {
	
	@SuppressWarnings("unchecked")
	AdminEntity save(AdminEntity admin);

	AdminEntity findByadminid(Long adminId);

}
